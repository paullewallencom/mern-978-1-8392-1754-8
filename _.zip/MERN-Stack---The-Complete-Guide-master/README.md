## $5 Tech Unlocked 2021!
[Buy and download this Video for only $5 on PacktPub.com](https://www.packtpub.com/product/mern-stack-the-complete-guide-video/9781839217548)
-----
*The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# MERN-Stack---The-Complete-Guide
MERN Stack - The Complete Guide, published by Packt
